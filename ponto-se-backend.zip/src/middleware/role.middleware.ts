import { Request, Response, NextFunction } from 'express';

export function hasRole(requiredRole: 'admin' | 'student') {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user as any;

    if (!user || user.role !== requiredRole) {
      return res.status(403).json({ message: 'Acesso negado: permissões insuficientes' });
    }

    next();
  };
}
