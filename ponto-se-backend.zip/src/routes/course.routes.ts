import { Router } from 'express';
import { CourseController } from '../controllers/course.controller';
import { isAuthenticated } from '../middleware/auth.middleware';
import { hasRole } from '../middleware/role.middleware';

const router = Router();

router.post('/', isAuthenticated, hasRole('admin'), CourseController.create);
router.get('/', CourseController.findAll);
router.get('/:id', CourseController.findById);

export default router;
