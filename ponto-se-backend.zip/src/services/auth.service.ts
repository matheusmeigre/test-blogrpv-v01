import { prisma } from '../config/prisma';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'default_secret';

export const AuthService = {
  async register({ name, email, password, role }: any) {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) throw new Error('E-mail já registrado');

    const hashedPassword = await bcrypt.hash(password, 10);

    return prisma.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        role
      }
    });
  },

  async login({ email, password }: any) {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw new Error('Usuário não encontrado');

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) throw new Error('Senha incorreta');

    const token = jwt.sign({ sub: user.id, role: user.role }, JWT_SECRET, {
      expiresIn: '7d'
    });

    return token;
  }
};
