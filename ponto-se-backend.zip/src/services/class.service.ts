import { prisma } from '../config/prisma';

export const ClassService = {
  async create(data: any) {
    return prisma.class.create({ data });
  },

  async getAll() {
    return prisma.class.findMany();
  },

  async getById(id: string) {
    return prisma.class.findUnique({ where: { id } });
  }
};
