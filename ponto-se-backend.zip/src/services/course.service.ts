import { prisma } from '../config/prisma';

export const CourseService = {
  async create(data: any) {
    return prisma.course.create({ data });
  },

  async getAll() {
    return prisma.course.findMany();
  },

  async getById(id: string) {
    return prisma.course.findUnique({ where: { id } });
  }
};
